export const UsersData = [
    {
      id: 1,
      name: "Leanne Graham",
      username: "Bret",
    },
    {
      id: 2,
      name: "Ervin Howell",
      username: "Antonette",
    },
    {
      id: 3,
      name: "Clementine Bauch",
      username: "clementine",
    },
    {
      id: 4,
      name: "Patricia Lebsack",
      username: "Karianne",
    },
    {
      id: 5,
      name: "Chelsey Dietrich",
      username: "Kamren",
    },
    {
      id: 6,
      name: "Jake Runolfsdottir V",
      username: "Leopoldo_Corkery",
    },
    {
      id: 7,
      name: "Mrs. Dennis Schulist",
      username: "Karley_Dach",
    },
    {
      id: 8,
      name: "Kurtis Weissnat",
      username: "Elwyn.Skiles",
    },
  ];