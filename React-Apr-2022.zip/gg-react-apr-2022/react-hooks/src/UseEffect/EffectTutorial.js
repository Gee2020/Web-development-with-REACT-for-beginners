import React, { useState, useEffect } from 'react';
//Install axio for API call
import axios from "axios";

function EffectTutorial ()  {
    const [data, setdata] = useState("");
    const [count, setCount] = useState("");
    
    useEffect (() => {
        //Axios API - to call web services
        axios.get("https://jsonplaceholder.typicode.com/comments")
        .then((response) => {
            setdata(response.data[10].email)
            console.log("AXIOS API Called");
        });
    }, []);
    
    return (
        <div>
            useEffect
            <h1>{data}</h1>
            <h1>{count}</h1>

            <button onClick={() => 
            setCount(count + 1)}>Click</button>
        </div>
    );
    
};

export default EffectTutorial;