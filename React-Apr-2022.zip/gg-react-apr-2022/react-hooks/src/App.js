import './App.css';
import StateTutorial from "./UseState/StateTutorial";
import EffectTutorial from './UseEffect/EffectTutorial';
import ContextTutorial from './UseContext/ContextTutorial';
import Login from './UseContext/Login';

function App() {
  return (
    <div className="App">
      <ContextTutorial />
    </div>
  );
}

export default App;
