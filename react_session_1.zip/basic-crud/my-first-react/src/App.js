import './App.css';

function MissedGoal(){
  return <h1>MISSED!</h1>;
}

function MadeGoal(){
  return <h1>GOAL!</h1>;
}

function Car(props) {
  return <li style={{color:"red"}}>I am a { props.brand } with Key</li>;
}

function App() {
  //EVENT
  // const shoot = () => {
  //   alert("GOAL!");
  // }

  // return (
  //   <button onClick={shoot}>Take the shot!</button>
  // );


  //IF Statement
  // const isGoal = true;
  
  // if (isGoal) {
  //   return <MadeGoal/>;
  // }

  // return <MissedGoal/>;

  //React Lists
  // const cars = ['Ford', 'BMW', 'Audi'];
  // return (
  //   <>
  //     <h1>Who lives in my garage?</h1>
  //     <ul>
  //       {cars.map((car) => <Car brand={car} />)}
  //     </ul>
  //   </>
  // );

  //React Lists with Key
  const cars = [
    {id:1, brand: 'Ford'},
    {id:2, brand: 'BMW'},
    {id:3, brand: 'Audi'}
  ];

  const myStyle = {
    color:"red",
    backgroundColor: "yellow",
    padding: "10px",
    fontFamily: "Sans-Serif"
  };

  return (
    <>
      <h1 style={myStyle}>Who lives in my garage?</h1>
      <ul>
        {cars.map((car) => <Car key={car.id} brand={car.brand} />)}
      </ul>
    </>
  );
}

export default App;
